var link = "";

function xx(ress) {
	var request = require('request');
	var cheerio = require('cheerio');

	var credentials = {
		login_user: 'nirwandogra_1',
		password: 'asshole'
	};
	request.post({
		uri: link,
		headers: {
			'content-type': 'application/x-www-form-urlencoded'
		},
		body: require('querystring').stringify(credentials)
	}, function(err, res, body) {
		if (err) {
			//callback.call(null, new Error('Login failed'));
			console.log("LOGIN failed");
			return;
		}
		var $ = cheerio.load(body);
		$('.kol1').each(function() {
			var th_text = $(this).find("a").first().text().trim();
			var file_name = "http://localhost:8080/files/src/save/" + th_text;
			console.log(file_name);
			var http = require('http');
			var fs = require('fs');
			var file = fs.createWriteStream(__dirname + "/files/" + th_text + ".cpp");
			var request = http.get(file_name, function(response) {
				response.pipe(file);
			});
		});
		ress.send(body);
	});
}
var express = require('express');
var app = express();
app.use(function(req, res, next) {
	link = "";
	if (req.url[1] == 's' && req.url[2] == 'u') {
		link = "http://www.spoj.com" + req.url + "";
	} else {
		link = "http://www.spoj.com" + req.url + "/";
	}
	xx(res);
});
app.listen(8080);
console.log('Server1 SSListening on port  8080 ');